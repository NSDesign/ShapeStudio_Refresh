# ShapeStudio_Refresh

![License](https://img.shields.io/badge/license-MIT-blue)
![Type](https://img.shields.io/badge/type-redevelopment%20brief%20%2B%20reference-6f42c1)
![Language](https://img.shields.io/badge/reference%20impl-TypeScript-3178c6?logo=typescript&logoColor=white)
![Source of truth](https://img.shields.io/badge/source%20of%20truth-the%20code-success)
![Status](https://img.shields.io/badge/status-living%20document-orange)

A complete documentation **and** reference-implementation set for rebuilding (or
incrementally refactoring) [**ShapeStudio**](https://github.com/NSDesign/ShapeStudio) —
a procedural geometric-composition tool. Everything here was reverse-engineered from the
actual codebase, with **code treated as authoritative** over the in-repo docs whenever the
two disagree.

> One line: build the implemented feature set (Appendices A–F), drop the deprecated Live
> State API and the Replit coupling (Appendix G), implement generation **once** in `shared/`
> behind a runtime-agnostic core, enforce client/server parity with a golden-output test,
> decompose the ~533-field config onto a single `ModeValue<T>` primitive, and put editor
> state in a selector store.

## Repository structure

| Path | What it is |
|---|---|
| `01-brief/` | **Start here.** The master redevelopment brief: product, stack, architecture, the binding Architecture Requirements (AR-1…AR-6), the implemented feature inventory, build sequence, and open decisions. |
| `02-appendices/` | Per-feature detail and schemas: **A** Shape System & Canvas · **B** Generation & Config Schema · **C** Distribution, Grid & Masking · **D** Effects, Colour & Echo · **E** Export & Print · **F** Persistence, Auth & Data Model · **G** Post-Implementation Notes (deprecated / incomplete / planned / removed). |
| `03-architecture/` | The measured evidence base behind the Architecture Requirements: five ranked structural problems + a refactor-vs-rebuild plan. |
| `04-reference-implementation/` | TypeScript contracts that turn AR-1/AR-3 into code: the generation-core interface, two `generateGeometry` worked examples (star, spline), a config-migration draft, and the Vitest parity-suite skeleton. |
| `05-batch-config-strangler/` | A working first increment of the rebuild: composed sub-config types on `ModeValue`, the generic flat↔composed adapter, a real decomposed `SizingPanel`, and a lossless round-trip test. |

## Quick start

**Read it** in this order: `01-brief/00-Master-Brief.md` → the relevant appendix in
`02-appendices/` → `03-architecture/Architecture-Review.md` → the code in `04-` and `05-`.

**Use the reference code.** The `04-` files are *contracts* — function bodies are
intentionally stubbed so they read as specifications (except `generateGeometry-star.ts`,
which is real math). The `05-batch-config-strangler/` files are **real, runnable**
TypeScript; start at `05-batch-config-strangler/mode-value.ts` (the keystone) and read
`05-batch-config-strangler/00-strangler-plan.md` for the migration sequence.

**Run the tests** (once wired into the ShapeStudio repo, where `@shared/schema` resolves):

```bash
npm i -D vitest
npx vitest run batch-config-roundtrip      # the strangler's lossless-round-trip gate
npx vitest run generation-parity           # the client/server parity gate (AR-2)
```

Names throughout are rename-friendly — **preserve the semantics, not the identifiers.**

## Conventions

- **Code is the source of truth.** Where these docs and the live code diverge, the code wins; such cases are flagged in Appendix G.
- **Architecture Requirements AR-1…AR-6 are binding**, not advisory (Master Brief §4).
- This is a **living document** — expect sections and reference files to grow.

## License

[MIT](./LICENSE) © 2026 NSDesign — edit the copyright holder to suit.
